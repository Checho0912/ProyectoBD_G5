<template><!-- As a link -->
    <!-- As a heading -->
    <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container-fluid justify-content-center">
            <a class="navbar-brand" href="#">EasyIT</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse flex-grow-0" id="navbarNav">
                <ul class="navbar-nav text-center">
                    <li class="nav-item">
                        <a class="nav-link" aria-current="page" href="/computadoras">Computadoras</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/no_retornables">Dispositivos no retornables</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="/oficina">Oficina</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " href="/historial">Historial</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>




</template>
<script>


</script>