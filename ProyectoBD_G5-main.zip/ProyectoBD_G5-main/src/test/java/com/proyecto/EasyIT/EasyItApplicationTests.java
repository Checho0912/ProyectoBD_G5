package com.proyecto.EasyIT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyItApplicationTests {

	@Test
	void contextLoads() {
	}

}
