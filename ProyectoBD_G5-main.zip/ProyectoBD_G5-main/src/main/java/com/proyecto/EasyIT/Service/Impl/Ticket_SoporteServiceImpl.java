package com.proyecto.EasyIT.Service.Impl;

import com.proyecto.EasyIT.Service.Ticket_SoporteService;
import org.springframework.stereotype.Service;

@Service
public class Ticket_SoporteServiceImpl implements Ticket_SoporteService {

//No supe implementar
}
