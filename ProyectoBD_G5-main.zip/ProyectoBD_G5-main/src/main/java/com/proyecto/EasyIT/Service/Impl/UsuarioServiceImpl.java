package com.proyecto.EasyIT.Service.Impl;

import com.proyecto.EasyIT.Service.UsuarioService;
import org.springframework.stereotype.Service;

@Service
public class UsuarioServiceImpl implements UsuarioService {

//No supe implementar
}
