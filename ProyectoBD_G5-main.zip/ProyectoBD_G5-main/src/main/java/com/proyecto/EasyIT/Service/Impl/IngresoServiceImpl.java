package com.proyecto.EasyIT.Service.Impl;

import com.proyecto.EasyIT.Service.IngresoService;
import org.springframework.stereotype.Service;

@Service
public class IngresoServiceImpl implements IngresoService {

//No supe implementar
}
