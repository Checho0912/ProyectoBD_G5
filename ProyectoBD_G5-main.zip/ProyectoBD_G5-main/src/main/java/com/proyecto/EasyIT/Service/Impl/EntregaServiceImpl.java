package com.proyecto.EasyIT.Service.Impl;

import com.proyecto.EasyIT.Service.EntregaService;
import org.springframework.stereotype.Service;

@Service
public class EntregaServiceImpl implements EntregaService {

//No supe implementar
}
