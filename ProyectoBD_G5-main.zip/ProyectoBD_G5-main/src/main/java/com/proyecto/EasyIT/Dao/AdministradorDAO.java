package com.proyecto.EasyIT.Dao;

import com.proyecto.EasyIT.Model.Administrador;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdministradorDAO extends JpaRepository<Administrador,String> {

}
