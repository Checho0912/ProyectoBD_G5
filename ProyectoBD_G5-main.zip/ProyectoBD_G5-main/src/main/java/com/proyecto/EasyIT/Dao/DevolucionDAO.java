package com.proyecto.EasyIT.Dao;

import com.proyecto.EasyIT.Model.Devolucion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DevolucionDAO extends JpaRepository<Devolucion,String> {

}
