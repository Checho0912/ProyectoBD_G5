package com.proyecto.EasyIT.Dao;

import com.proyecto.EasyIT.Model.Ingreso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IngresoDAO extends JpaRepository<Ingreso,String> {

}
