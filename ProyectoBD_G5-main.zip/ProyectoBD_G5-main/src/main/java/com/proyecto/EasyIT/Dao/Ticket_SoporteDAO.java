package com.proyecto.EasyIT.Dao;

import com.proyecto.EasyIT.Model.Ticket_Soporte;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Ticket_SoporteDAO extends JpaRepository<Ticket_Soporte,String> {

}
