package com.proyecto.EasyIT.Service.Impl;

import com.proyecto.EasyIT.Service.Ticket_SolicitudService;
import org.springframework.stereotype.Service;

@Service
public class Ticket_SolicitudServiceImpl implements Ticket_SolicitudService {

//No supe implementar
}
