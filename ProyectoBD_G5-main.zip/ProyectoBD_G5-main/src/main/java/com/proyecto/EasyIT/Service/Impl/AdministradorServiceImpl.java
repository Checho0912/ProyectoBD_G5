package com.proyecto.EasyIT.service.impl;

import com.proyecto.EasyIT.Model.Administrador;
import com.proyecto.EasyIT.Dao.AdministradorDAO;
import com.proyecto.EasyIT.Service.AdministradorService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdministradorServiceImpl implements AdministradorService {

//No supe implementar
}
