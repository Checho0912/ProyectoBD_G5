package com.proyecto.EasyIT.Dao;

import com.proyecto.EasyIT.Model.Entrega;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntregaDAO extends JpaRepository<Entrega,String> {

}
