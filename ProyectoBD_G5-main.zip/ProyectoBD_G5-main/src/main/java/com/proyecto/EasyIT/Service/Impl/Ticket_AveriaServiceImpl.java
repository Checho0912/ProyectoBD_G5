package com.proyecto.EasyIT.Service.Impl;

import com.proyecto.EasyIT.Service.Ticket_AveriaService;
import org.springframework.stereotype.Service;

@Service
public class Ticket_AveriaServiceImpl implements Ticket_AveriaService {

//No supe implementar
}
