package com.proyecto.EasyIT.Service;

import com.proyecto.EasyIT.Model.Country;

import java.util.List;

public interface CountryService {

    public List<Country> getCountries();
}
