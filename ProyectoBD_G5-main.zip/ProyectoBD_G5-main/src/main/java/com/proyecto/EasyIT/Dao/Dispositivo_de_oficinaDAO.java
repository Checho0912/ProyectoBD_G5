package com.proyecto.EasyIT.Dao;


import com.proyecto.EasyIT.Model.Dispositivo_de_oficina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Dispositivo_de_oficinaDAO extends JpaRepository<Dispositivo_de_oficina, Long> {
}
