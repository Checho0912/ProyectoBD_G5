package com.proyecto.EasyIT.Service.Impl;

import com.proyecto.EasyIT.Service.DevolucionService;
import org.springframework.stereotype.Service;

@Service
public class DevolucionServiceImpl implements DevolucionService {

//No supe implementar
}
